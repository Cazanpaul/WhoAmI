package com.example.victor.myapplication;

import com.esafirm.imagepicker.model.Image;

/**
 * Created by Victor on 1/7/2018.
 */

public class Friend {

    private Image friendPhoto;
    private String email;

    public Friend(Image i, String e)
    {
        friendPhoto = i;
        email = e;
    }

    public Image getFriendPhoto() {
        return friendPhoto;
    }

    public String getEmail() {
        return email;
    }
}
