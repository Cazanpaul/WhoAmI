package com.example.victor.myapplication;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by Victor on 1/7/2018.
 */

public class FriendViewHolder extends RecyclerView.ViewHolder {
    protected TextView text;
    protected Button button;

    public FriendViewHolder(View itemView) {
        super(itemView);
        text= itemView.findViewById(R.id.text_id);
        button= itemView.findViewById(R.id.deleteButton);
    }
}
