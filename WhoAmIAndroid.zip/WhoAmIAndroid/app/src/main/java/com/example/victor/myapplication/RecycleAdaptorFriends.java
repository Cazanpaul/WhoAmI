package com.example.victor.myapplication;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Victor on 18/11/2017.
 */

public class RecycleAdaptorFriends extends RecyclerView.Adapter<FriendViewHolder> {

    List<Friend> friends;
    DynamoDBMapper map;
    String user;

    public RecycleAdaptorFriends(List<Friend> preteni, DynamoDBMapper map, String user) {
        this.map = map;
        friends = preteni;
        this.user = user;
    }

    @Override
    public FriendViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.friends_layout, parent, false);
        FriendViewHolder viewHolder = new FriendViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(FriendViewHolder holder, final int position) {
        holder.text.setText(friends.get(position).getEmail());
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBFriend friend = new DBFriend();
                friend.setUser(user);
                Set<String> str = new HashSet<>();
                for (Friend fr : friends) {
                    str.add(fr.getEmail());
                }


                friend.setFriends(str);


                friends.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, friends.size());
                if (!friends.isEmpty()) {


                    DBFriend friend2 = new DBFriend();
                    friend2.setUser(user);
                    Set<String> str2 = new HashSet<>();
                    for (Friend fr : friends) {
                        str2.add(fr.getEmail());
                    }


                    friend2.setFriends(str2);
                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            map.save(friend2);
                        }
                    };
                    Thread th = new Thread(runnable);
                    th.start();
                } else {
                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            map.delete(friend);
                        }
                    };
                    Thread th = new Thread(runnable);
                    th.start();
                }


            }
        });
    }

    @Override
    public int getItemCount() {
        return friends.size();
    }
}