package com.example.victor.myapplication;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.util.Set;

/**
 * Created by Victor on 1/9/2018.
 */
@DynamoDBTable(tableName = "Friends")
public class DBFriend {


    private String user;
    private Set<String> friends;

    @DynamoDBHashKey(attributeName = "User")
    public String getUser(){
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setFriends(Set<String> friends) {
        this.friends = friends;
    }


    @DynamoDBAttribute(attributeName = "Friends")
    public Set<String> getFriends(){
        return friends;
    }
}