package com.example.victor.myapplication;

import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBAttribute;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBDocument;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBHashKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBIndexRangeKey;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBTable;

import java.io.File;
import java.util.List;
import java.util.Set;

/**
 * Created by Victor on 1/7/2018.
 */
@DynamoDBTable(tableName = "Photos")
public class Person {

    private String face;
    private Set<String> photos;

    @DynamoDBHashKey(attributeName = "Face")
    public String getFace(){
        return face;
    }

    public void setFace(String face) {
        this.face = face;
    }

    public void setPhoto(Set<String> photos) {
        this.photos = photos;
    }


    @DynamoDBAttribute(attributeName = "Photo")
    public Set<String>getPhoto(){
        return photos;
    }
}
