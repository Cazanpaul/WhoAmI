package com.example.victor.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.mobileconnectors.dynamodbv2.dynamodbmapper.DynamoDBMapper;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.esafirm.imagepicker.features.ImagePicker;
import com.esafirm.imagepicker.features.camera.OnImageReadyListener;
import com.esafirm.imagepicker.model.Image;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_PICKER_FOR_ADD_FRIEND = 9995;
    public static final int REQUEST_CODE_PICKER_FOR_UPLOAD = 25;
    public static final String BUCKET_NAME = "whoamirekog";
    private SharedPreferences sharedPreferences;

    private final static String PREFS_SETTINGS = "prefs_settings";

    private static final String CURRENT_USER = "Current user: ";
    private AmazonDynamoDBClient ddbClient;
    private  DynamoDBMapper mapper ;

    private String defaultPath = Environment
            .getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            .getAbsolutePath() + File.separator + "WhoAmI" + File.separator;
    private Button addFriend;

    private Button upload;

    private Button setUser;

    private Button downloadButton;
    private EditText emailField;

    private RecyclerView rView;
    private RecycleAdaptorFriends adapter;

    private TextView currentUser;
    private String user;

    private AmazonS3 s3 ;
    List<Friend> friends;
    private TransferUtility transferUtility;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rView = (RecyclerView) findViewById(R.id.rView);
        friends = new ArrayList<Friend>();
        addFriend = (Button) findViewById(R.id.addFriendButton);
        upload = (Button) findViewById(R.id.uploadButton);
        emailField = (EditText)  findViewById(R.id.emailField);
        downloadButton = (Button) findViewById(R.id.download);
        setUser = (Button)  findViewById(R.id.setUser);
        currentUser = (TextView) findViewById(R.id.currentUser);
        currentUser.setText("Please log in, to avoid crashing, by pressing buttons");
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        rView.setLayoutManager(mLayoutManager);


        addListeners();


        // Initialize the Amazon Cognito credentials provider
        CognitoCachingCredentialsProvider credentialsProvider = new CognitoCachingCredentialsProvider(
                getApplicationContext(),
                "eu-west-1:5fd4ccfa-415a-4806-b8e9-395a91428f77", // Identity pool ID
                Regions.EU_WEST_1 // Region
        );

        s3 = new AmazonS3Client(credentialsProvider);
        transferUtility = new TransferUtility(s3,getApplicationContext() );
         ddbClient = new AmazonDynamoDBClient(credentialsProvider);

        ddbClient.setRegion(Region.getRegion(Regions.EU_WEST_1));

        mapper = new DynamoDBMapper(ddbClient);

    sharedPreferences = getSharedPreferences(PREFS_SETTINGS,Context.MODE_PRIVATE);
    user = sharedPreferences.getString("USERKEY",null);
    if(user!=null) {
        currentUser.setText(CURRENT_USER + user);
        loadfriends();
    }
    }


    private void loadfriends() {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    DBFriend preten = mapper.load(DBFriend.class, user);
                    Set<String> amici = preten.getFriends();


                    for (String f : amici) {
                        Friend q = new Friend(null, f);
                        friends.add(q);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter = new RecycleAdaptorFriends(friends,mapper,user);
                            rView.setAdapter(adapter);
                        }
                    });

                } catch (NullPointerException e) {
                    //nothing
                }
            }





        };
        Thread mythread = new Thread(runnable);
        mythread.start();
    }
    private Activity getMe()
    {
        return this;
    }
    private void addListeners()
    {
        addFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("BUTTON","BUTTON");

                if(!emailField.getText().toString().isEmpty())
                {ImagePicker.create(getMe()).single().start(REQUEST_CODE_PICKER_FOR_ADD_FRIEND);}
            }
        });

        upload.setOnClickListener((view) ->{
            ImagePicker.create(getMe()).start(REQUEST_CODE_PICKER_FOR_UPLOAD);

        });

        setUser.setOnClickListener((view)->{
            if(emailField.getText().toString()!=null && !emailField.getText().toString().isEmpty()){
            friends.clear();
            user = emailField.getText().toString();
            currentUser.setText(CURRENT_USER + user);
                SharedPreferences.Editor e = sharedPreferences.edit();
                e.putString("USERKEY",user);
                e.apply();
            loadfriends();}
        });
        downloadButton.setOnClickListener((view)->{
            Runnable runnable = () -> {
                if(user!=null&&user!="") {
                    Person persoana = mapper.load(Person.class, user);
                    if (persoana != null) {
                        for (String f : persoana.getPhoto()) {
                            File f1 = new File(defaultPath + f);
                            TransferObserver observer = transferUtility.download(BUCKET_NAME, f, f1);

                            observer.setTransferListener(new TransferListener() {

                                @Override
                                public void onStateChanged(int id, TransferState state) {
                                    Log.d("stateLog", state.name());
                                }

                                @Override
                                public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                                    if (bytesTotal != 0) {
                                        int percentage = (int) (bytesCurrent / bytesTotal * 100);
                                        Log.d("stateLog", "" + percentage);
                                    }
                                }

                                @Override
                                public void onError(int id, Exception ex) {
                                    Log.d("stateLog", ex.getMessage());
                                }

                            });
                        }
                    }
                }
            };
            Thread mythread = new Thread(runnable);
            mythread.start();


        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_PICKER_FOR_ADD_FRIEND && resultCode == RESULT_OK && data != null) {
            //if we got an image

            ArrayList<Image> images = (ArrayList<Image>) ImagePicker.getImages(data);
            String email = emailField.getText().toString();
            Friend f = new Friend(images.get(0),email);
            friends.add(f);
            emailField.getText().clear();
            adapter = new RecycleAdaptorFriends(friends,mapper,user);
            rView.setAdapter(adapter);

            DBFriend friend = new DBFriend();
            friend.setUser(user);
            Set<String> SS = new HashSet<>() ;
            for(Friend fr: friends)
            {
                SS.add(fr.getEmail());
            }
            friend.setFriends(SS);
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    mapper.save(friend);
                }
            };
            Thread th = new Thread(runnable);
            th.start();

            Map<String,String> meta = new HashMap<String,String>();
            meta.put("user",user);
            meta.put("friend",f.getEmail().replace('@','_'));
            String userFile = user+"/"+ images.get(0).getName();
            File poza = new File(images.get(0).getPath());
            Log.d("pozza",images.get(0).getPath());
            ObjectMetadata myObjectMetadata = new ObjectMetadata();

            myObjectMetadata.setUserMetadata(meta);
            TransferObserver observer = transferUtility.upload("whoamireg",userFile,poza,myObjectMetadata);
            observer.setTransferListener(new TransferListener(){

                @Override
                public void onStateChanged(int id, TransferState state) {
                    Log.d("stateLog",state.name());
                }

                @Override
                public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                    int percentage = (int) (bytesCurrent/bytesTotal * 100);
                  Log.d("stateLog","" + percentage);
                }

                @Override
                public void onError(int id, Exception ex) {
                    Log.d("stateLog","ERROR");
                }

            });


            }
        if (requestCode == REQUEST_CODE_PICKER_FOR_UPLOAD && resultCode == RESULT_OK && data != null) {
            ArrayList<Image> images = (ArrayList<Image>) ImagePicker.getImages(data);

            for(Image i: images){
                ObjectMetadata myObjectMetadata = new ObjectMetadata();
                Map<String,String> meta = new HashMap<String,String>();
                meta.put("user",user);
                String userFile = user +'/'+ i.getName();
                File poza = new File( i.getPath());
                String bucket = "whoamirekog";
                myObjectMetadata.setUserMetadata(meta);
                TransferObserver observer = transferUtility.upload(bucket,userFile,poza,myObjectMetadata);

                observer.setTransferListener(new TransferListener(){

                    @Override
                    public void onStateChanged(int id, TransferState state) {
                        Log.d("stateLog",state.name());
                    }

                    @Override
                    public void onProgressChanged(int id, long bytesCurrent, long bytesTotal) {
                        int percentage = (int) (bytesCurrent/bytesTotal * 100);
                        Log.d("stateLog","" + percentage);
                    }

                    @Override
                    public void onError(int id, Exception ex) {
                        Log.d("stateLog","ERROR");
                    }

                });


            }


        }

        }
}
